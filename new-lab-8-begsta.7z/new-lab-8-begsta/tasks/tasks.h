#ifndef TASKS_H
#define TASKS_H
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <random>
#include <list>
#include <map>

class Card{
    std::string title;
    std::string author;
    int number;
public:
    Card(std::string t = "", std::string a = "", int n = 0) : title{t}, author{a}, number(n) {}
    friend void printVec(const std::vector<Card>);
    std::string & getAut(void) {return author;}
    std::string & getTit(void) {return title;}
};

class Complex{
    double Re, Im;
public:
    Complex(double r = 0,  double i = 0) : Re{r}, Im{i} {}
    friend void printCom(const std::list<Complex>);
};


namespace MT{
    void checkString(const std::string &);
    void takeEvenStr(const std::string & );
    void modifyFile(const char, const char);
    void printVec(const std::vector<float>);
    void printList(const std::list<int>);
    void workWithVector(void);
    void workWithCard(void);
    void workWithList(void);
    void workMap(void);
    void workMapString(void);
    void listComplex(void);
};

#endif