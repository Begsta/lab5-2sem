#include "tasks.h"

/**
 * @brief Function to check string on simvol ;
 * @param str String which need to check
 */
void MT::checkString(const std::string & str){
    int t = 0;
    while (true) {
        t = str.find(";", t);
        if (t == std::string::npos)
            return;
        std::cout << ++t << std::endl;
    }
}

/**
 * @brief Function which send only even simvol of string
 * @param str String which send simvol 
 */
void MT::takeEvenStr(const std::string & str){
    std::string result;
    for (int i = 1; i < str.size(); i += 2) {result += str[i];}
    std::cout << result << std::endl;
}

/**
 * @brief Modify File to chage old simvol on new
 * @param nCh New simvol
 * @param oCh Old simvol
 */
void MT::modifyFile(const char nCh, const char oCh){
    std::ifstream in; // чтение
    std::ofstream out; // запись
    std::string str;
    int t = 0;
    out.open("newFile.txt");
    in.open("oldFile.txt");
    if (in.is_open() && out.is_open()){
        while (std::getline(in, str))
        {
            while (true) {
                t = str.find(oCh, t);
                if (t == std::string::npos)
                    break;
                str[t++] = nCh;
            }
            out << str;
        }
    }
    in.close();
    out.close();
}

/**
 * @brief Function to print vector in terminal
 */
void MT::printVec(const std::vector<float> vec){
    std::cout << "{";
    for (float f : vec){ std::cout << ' ' << f;  }
    std::cout << " }" << std::endl;
}

/**
 * @brief Function to print list in terminal
 */
void MT::printList(const std::list<int> array){
    std::cout << "{";
    for (float f : array){ std::cout << ' ' << f;  }
    std::cout << " }" << std::endl;
}

/**
 * @brief Function to print vector in terminal
 */
void printVec(const std::vector<Card> vec){
    std::cout << "---------------------------------------------------------------------------------------------------------------" << std::endl;
    for(int i = 0; i < vec.size(); i++){
        std::cout << "Title: " << vec[i].title << std::endl <<
        "Author: " << vec[i].author << std::endl << 
        "Number " << vec[i].number << std::endl << std::endl;
    }
    std::cout << "------------------------------------------------------------------------------------------------------------------" << std::endl;
}

/**
 * @brief Function to create
 */
void MT::workWithVector(void){
    std::vector<float> vec;
    for (int i = 0; i < 25; i++) { vec.push_back(static_cast<float>(rand())/ RAND_MAX * 100 + 10); }
    printVec(vec);
    for (int i = 0; i < 25; i++) {vec[i] = vec[i]*vec[i]; }
    printVec(vec);
    vec.erase(vec.begin() + 4);
    printVec(vec);
}

/**
 * @brief Function which work with class Card
 */
void MT::workWithCard(void){
    int n;
    std::string t, a;
    std::vector<Card> vec;
    for (int i = 0; i < 5; i++){
        std::cout << "Continue?(1/0)"; std::cin>>n;
        if (!n)
            break;
        std::cout << "Enter number: "; std::cin >> n;
        std::cout << "Enter title: "; std::cin >> t;
        std::cout << "Enter author: "; std::cin >> a;
        vec.push_back(Card(t,a,n));
    } 
    printVec(vec);
    n = 0;
    std::cout << "Enter author: "; std::cin >> a;
    for (Card i : vec){
        if (i.getAut() == a){
            std::cout << i.getTit() << std::endl;
            n++;
        }   
    } 
    if (n==0){std::cout << "Book not found" << std::endl; }
}

/**
 * @brief Create list of int and check if number 5 in list
 */
void MT::workWithList(void){
    std::list<int> array;
    int a;
    for (int i = 0; i < 25; i++) { array.push_back(rand() % 50); }
    printList(array);
    std::cin >> a;
    for(int i : array){
        if (i == a){
            std::cout << "Yes" << std::endl;
            return;
        }
    }
    std::cout << "No" << std::endl;
}

/**
 * @brief Function work with map int
 */
void MT::workMap(void){
    std::map<int, int> numbers;
    for(int i =1 ; i < 21; i++) numbers[i] = i*10;
    for (const auto& [numbers, num1] : numbers) std::cout << numbers << "\t" << num1 << std::endl; std::cout << std::endl;
    for(int i =1 ; i < 21; i+=2) numbers.erase(i);
    for (const auto& [numbers, num1] : numbers) std::cout << numbers << "\t" << num1 << std::endl;
}

/**
 * @brief Create map of worcker
 */
void MT::workMapString(void){
    std::map<std::string, int> mapPrice;
    std::map<std::string, std::string> mapPosition;
    std::map<std::string, int> mapTotal;
    std::string name, Position;
    int sum, total = 0;
    while (true) {
        std::cout << "Continue?(1/0)"; std::cin>>sum;
        if (!sum)
            break;
        std::cout << "Name: "; std::cin>>name;
        std::cout << "Salary: "; std::cin>>sum;
        std::cout << "Position: "; std::cin>>Position;
        mapPosition[name] = Position;
        mapPrice[name] = sum;
    }
    for (const auto& [name, sum] : mapPrice) std::cout << name << "\t" << sum << std::endl; std::cout << std::endl;
    for (const auto& [name, Position] : mapPosition) std::cout << name << "\t" << Position << std::endl; std::cout << std::endl;
    for (const auto& [name, sum] : mapPrice){
        if (mapTotal.count(mapPosition[name]) ==0)
            mapTotal[mapPosition[name]] = 0;
        mapTotal[mapPosition[name]] += sum;
        total += sum;
    }
    for (const auto& [Position, sum] : mapTotal) std::cout << Position << "\t" << sum << std::endl; std::cout << std::endl;
    std::cout << "Overrall" << "\t" <<  total << std::endl;
}

/**
 * @brief Print complew number
 */
void printCom(const std::list<Complex> array){
    double sumR = 0, sumI = 0;
    for( Complex num : array){
        sumI+=num.Im;
        sumR += num.Re;
        std::cout << num.Re << ((num.Im > 0) ? " + " : " - " ) << " i * " << abs(num.Im)  << std::endl;
    }
    std::cout << "Sum of coplex number: "<< sumR << ((sumI > 0) ? " + " : " - " ) << " i * " << abs(sumI)  << std::endl;
}

/**
 * @brief Create list complex number
 */
void MT::listComplex(void){
    std::list<Complex> array;
    for (int i = 0; i < 6; i++){ array.push_back(Complex(static_cast<float>(rand())/ RAND_MAX * 10 - 5, static_cast<float>(rand()-12)/ RAND_MAX * 10 - 5)); }
    printCom(array);
}

