#include "tasks/tasks.h"

void interface(void);

/**
 * @brief Main of program function
 */
int main(void){
    interface();
    return 0;
}


/**
 * @brief UI function
 */
void interface(void){
    using std::cout, std::endl, std::cin;
    char nCh, oCh;
    std::string str;
    int ch;
    while (true){
        cout << "Choose tasks(1-9): ";
        cin >> ch;
        switch (ch){
            case 1:
                cout << "Enter string: "; cin >> str;
                MT::checkString(str);
                break;
            case 2:
                cout << "Enter string: "; cin >> str;
                MT::takeEvenStr(str);
                break;
            case 3:
                cout << "Enter new char: "; cin >> nCh;
                cout << "Enter old char: "; cin >> oCh;
                MT::modifyFile(nCh, oCh);
                break;
            case 4:
                MT::workWithVector();
                break;
            case 5:
                MT::workWithCard();
                break;
            case 6:
                MT::workWithList();
                break;
            case 7:
                MT::listComplex();
                break;
            case 8:
                MT::workMap();
                break;
            case 9:
                MT::workMapString();
                break;
            default:
                return;
        }
    }
}